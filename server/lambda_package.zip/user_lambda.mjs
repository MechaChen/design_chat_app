import { DynamoDBClient, QueryCommand } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient } from '@aws-sdk/lib-dynamodb';

const client = new DynamoDBClient({});
const documentClient = DynamoDBDocumentClient.from(client);

export const handler = async (event) => {
    try {
        const { Items } = await documentClient.send(new QueryCommand({
            TableName: 'users',
            KeyConditionExpression: 'email = :email',
            ExpressionAttributeValues: {
                ':email': event.email   ,
            },
        }));
    
        if (Items.length <= 0) {
            await documentClient.send(new PutItemCommand({
                TableName: 'users',
                Item: {
                    email: event.email,
                },
            }));
        }
        
        return {
          statusCode: 200,
          body: JSON.stringify({
            message: 'Success',
          }),
        };
    } catch (error) {
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: error.message,
            }),
        };
    }
};

export { client };
